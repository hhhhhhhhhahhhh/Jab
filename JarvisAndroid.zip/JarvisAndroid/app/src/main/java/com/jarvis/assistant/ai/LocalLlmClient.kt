package com.jarvis.assistant.ai

import android.content.Context
import com.llamatik.LlamaBridge
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume

/**
 * Runs a small language model directly on the phone via llama.cpp (Llamatik).
 * No internet needed after the one-time model download, no API key, no quota.
 * This is a plain chat fallback — it does NOT do tool/function calling; fixed
 * commands (open app, WhatsApp, weather, etc.) are still handled by
 * LocalCommandParser before this is ever reached.
 */
class LocalLlmClient(private val context: Context) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(5, TimeUnit.MINUTES)
        .build()

    private val modelFile: File
        get() = File(context.filesDir, MODEL_FILENAME)

    val isModelDownloaded: Boolean
        get() = modelFile.exists() && modelFile.length() > 50_000_000L

    private var modelLoaded = false

    /** Downloads the GGUF model (~1 GB) once. Call from a coroutine; reports 0-100 progress. */
    suspend fun downloadModel(onProgress: (Int) -> Unit): Boolean = withContext(Dispatchers.IO) {
        if (isModelDownloaded) return@withContext true
        try {
            val request = Request.Builder().url(MODEL_URL).build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@withContext false
                val body = response.body ?: return@withContext false
                val total = body.contentLength().takeIf { it > 0 } ?: (1_100_000_000L)
                val tempFile = File(context.filesDir, "$MODEL_FILENAME.part")
                body.byteStream().use { input ->
                    tempFile.outputStream().use { output ->
                        val buffer = ByteArray(64 * 1024)
                        var readBytes: Long = 0
                        var n: Int
                        while (true) {
                            n = input.read(buffer)
                            if (n == -1) break
                            output.write(buffer, 0, n)
                            readBytes += n
                            onProgress(((readBytes * 100) / total).toInt().coerceIn(0, 100))
                        }
                    }
                }
                tempFile.renameTo(modelFile)
            }
            isModelDownloaded
        } catch (e: Exception) {
            false
        }
    }

    private fun ensureLoaded() {
        if (!modelLoaded && isModelDownloaded) {
            LlamaBridge.initGenerateModel(modelFile.absolutePath)
            modelLoaded = true
        }
    }

    suspend fun reply(systemPrompt: String, userText: String): String = withContext(Dispatchers.IO) {
        if (!isModelDownloaded) return@withContext "Yerel model henüz indirilmedi."
        ensureLoaded()

        try {
            suspendCancellableCoroutine { cont ->
                val builder = StringBuilder()
                LlamaBridge.generateStreamWithContext(
                    system = systemPrompt,
                    context = "",
                    user = userText,
                    onDelta = { token -> builder.append(token) },
                    onDone = { if (cont.isActive) cont.resume(builder.toString().ifBlank { "..." }) },
                    onError = { err -> if (cont.isActive) cont.resume("Yerel model hatası: $err") }
                )
            }
        } catch (e: Exception) {
            "Yerel model hatası: ${e.message}"
        }
    }

    companion object {
        private const val MODEL_FILENAME = "qwen2.5-1.5b-instruct-q4_k_m.gguf"
        private const val MODEL_URL =
            "https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct-GGUF/resolve/main/qwen2.5-1.5b-instruct-q4_k_m.gguf"
    }
}

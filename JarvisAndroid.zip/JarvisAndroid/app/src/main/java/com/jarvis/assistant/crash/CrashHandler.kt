package com.jarvis.assistant.crash

import android.content.Context
import android.content.Intent
import android.os.Process
import java.io.PrintWriter
import java.io.StringWriter
import kotlin.system.exitProcess

class CrashHandler(private val appContext: Context) : Thread.UncaughtExceptionHandler {

    private val defaultHandler: Thread.UncaughtExceptionHandler? =
        Thread.getDefaultUncaughtExceptionHandler()

    override fun uncaughtException(thread: Thread, throwable: Throwable) {
        if (alreadyHandling) {
            // A crash happened while we were already handling one (e.g. during activity
            // teardown) — ignore it so the original error stays visible on screen.
            return
        }
        alreadyHandling = true
        try {
            val sw = StringWriter()
            throwable.printStackTrace(PrintWriter(sw))

            val intent = Intent(appContext, CrashActivity::class.java).apply {
                putExtra("trace", sw.toString())
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            }
            appContext.startActivity(intent)
        } catch (e: Exception) {
            defaultHandler?.uncaughtException(thread, throwable)
        } finally {
            Thread.sleep(500)
            Process.killProcess(Process.myPid())
            exitProcess(1)
        }
    }

    companion object {
        @Volatile private var alreadyHandling = false
    }
}

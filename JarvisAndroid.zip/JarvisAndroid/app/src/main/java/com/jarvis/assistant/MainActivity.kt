package com.jarvis.assistant

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.jarvis.assistant.ai.LocalLlmClient
import com.jarvis.assistant.core.ChatAdapter
import com.jarvis.assistant.core.ChatMessage
import com.jarvis.assistant.core.LocalCommandParser
import com.jarvis.assistant.voice.SpeechManager
import kotlinx.coroutines.launch

/**
 * JARVIS — API'siz sürüm + telefonda çalışan yerel AI (Llamatik/llama.cpp).
 * Sabit komutlar (uygulama aç, hava durumu, whatsapp, vb.) LocalCommandParser
 * ile anında ve %100 offline çalışır. Bunlara uymayan her şey, telefonda
 * çalışan küçük bir dil modeline (indirildikten sonra tamamen offline) sorulur.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var speechManager: SpeechManager
    private lateinit var adapter: ChatAdapter
    private lateinit var localLlm: LocalLlmClient

    private val messages = mutableListOf<ChatMessage>()
    private val permissionRequestCode = 42

    private val systemPrompt = "Sen JARVIS'sin, telefonda çalışan kısa ve yardımsever bir Türkçe asistansın. Kısa ve net cevaplar ver."

    private val helpText = """
        Şunları deneyebilirsin:
        • "Spotify aç", "Google aç"
        • "İstanbul'da hava durumu"
        • "pil durumu", "ram durumu", "depolama durumu", "saat kaç"
        • "Ali'ye whatsapp'tan merhaba yaz"
        • "böyle bir şarkı çal"
        • "14:30'da toplantı hatırlat"
        • "sesi değiştir"
        Bunların dışındaki her şeyi telefonda çalışan yerel AI modeline soracağım.
    """.trimIndent()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)
        requestRuntimePermissions()

        speechManager = SpeechManager(this)
        localLlm = LocalLlmClient(this)

        val recycler = findViewById<RecyclerView>(R.id.chatRecycler)
        adapter = ChatAdapter(messages)
        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = adapter

        val input = findViewById<EditText>(R.id.messageInput)
        val sendButton = findViewById<ImageButton>(R.id.sendButton)
        val micButton = findViewById<ImageButton>(R.id.micButton)
        val voiceChangeButton = findViewById<ImageButton>(R.id.voiceChangeButton)

        addMessage("Merhaba! Ben JARVIS. $helpText", isUser = false)
        ensureLocalModelReady()

        voiceChangeButton.setOnClickListener {
            val result = speechManager.cycleVoice()
            addMessage(result, isUser = false)
        }

        sendButton.setOnClickListener {
            val text = input.text.toString().trim()
            if (text.isNotEmpty()) {
                input.setText("")
                handleUserMessage(text)
            }
        }

        micButton.setOnClickListener { startVoiceInput() }

        if (hasRecordAudioPermission()) {
            android.os.Handler(mainLooper).postDelayed({ startVoiceInput() }, 400)
        }
    }

    /** Downloads the on-device model once, in the background, showing progress in the chat. */
    private fun ensureLocalModelReady() {
        if (localLlm.isModelDownloaded) return
        addMessage(
            "Yerel yapay zeka modelini indiriyorum (~1 GB, bir kereliğine, Wi-Fi önerilir)... " +
                "Bu sürede sabit komutlar (uygulama aç, hava durumu vb.) yine çalışır.",
            isUser = false
        )
        lifecycleScope.launch {
            var lastReported = -10
            val ok = localLlm.downloadModel { percent ->
                if (percent - lastReported >= 20) {
                    lastReported = percent
                    runOnUiThread { addMessage("Model indiriliyor: %$percent", isUser = false) }
                }
            }
            addMessage(
                if (ok) "Yerel model hazır, artık serbest sohbet de tamamen offline çalışıyor."
                else "Model indirilemedi (internet bağlantını kontrol et). Sabit komutlar yine çalışır.",
                isUser = false
            )
        }
    }

    private fun hasRecordAudioPermission(): Boolean {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
    }

    private fun startVoiceInput() {
        if (!hasRecordAudioPermission()) {
            requestRuntimePermissions()
            return
        }
        speechManager.startListening(
            onResult = { text -> handleUserMessage(text) },
            onError = { err -> addMessage(err, isUser = false) }
        )
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == permissionRequestCode && hasRecordAudioPermission()) {
            startVoiceInput()
        }
    }

    private fun handleUserMessage(text: String) {
        addMessage(text, isUser = true)

        val normalized = text.trim().lowercase()
        if (normalized.contains("sesi değiştir") || normalized.contains("sesini değiştir") ||
            normalized.contains("ses değiştir")
        ) {
            addMessage(speechManager.cycleVoice(), isUser = false)
            return
        }

        val localResult = LocalCommandParser.tryHandle(this, normalized)
        if (localResult != null) {
            addMessage(localResult, isUser = false)
            speechManager.speak(localResult)
            return
        }

        if (!localLlm.isModelDownloaded) {
            val msg = "Yerel model henüz indirilmedi, biraz bekleyip tekrar dener misin?"
            addMessage(msg, isUser = false)
            speechManager.speak(msg)
            return
        }

        lifecycleScope.launch {
            val reply = localLlm.reply(systemPrompt, text)
            addMessage(reply, isUser = false)
            speechManager.speak(reply)
        }
    }

    private fun addMessage(text: String, isUser: Boolean) {
        adapter.addMessage(ChatMessage(text, isUser))
        findViewById<RecyclerView>(R.id.chatRecycler).scrollToPosition(messages.size - 1)
    }

    private fun requestRuntimePermissions() {
        val needed = listOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_CALENDAR,
            Manifest.permission.WRITE_CALENDAR,
            Manifest.permission.READ_CONTACTS
        ).filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (needed.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, needed.toTypedArray(), permissionRequestCode)
        }
    }

    override fun onDestroy() {
        if (::speechManager.isInitialized) {
            speechManager.destroy()
        }
        super.onDestroy()
    }
}

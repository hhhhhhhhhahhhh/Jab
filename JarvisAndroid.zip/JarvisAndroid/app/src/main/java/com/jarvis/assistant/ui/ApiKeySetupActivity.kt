package com.jarvis.assistant.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.jarvis.assistant.MainActivity
import com.jarvis.assistant.R
import com.jarvis.assistant.core.Config

class ApiKeySetupActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_api_key_setup)

        val config = Config(this)
        val input = findViewById<EditText>(R.id.apiKeyInput)
        val saveButton = findViewById<Button>(R.id.saveKeyButton)

        saveButton.setOnClickListener {
            val key = input.text.toString().trim()
            if (key.isBlank()) {
                Toast.makeText(this, "Bir API anahtarı gir.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            config.apiKey = key
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
    }
}
